"""
pseudolikelihood maximization direct coupling analysis (plmDCA) module for 
protein and RNA multiple sequence alignments. 
"""