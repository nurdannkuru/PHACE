"""Implements mean-field algorithm of direct coupling analysis (DCA) for protein
and RNA families.
"""
