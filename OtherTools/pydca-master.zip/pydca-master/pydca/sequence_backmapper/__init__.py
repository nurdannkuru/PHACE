"""This module backmappes a reference sequence's sites to the protein/RNA family
multiple sequence alignment columns.
"""
