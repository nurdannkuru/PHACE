"""Implements visualization tools for contact map comparison and true positive
plots.
"""
