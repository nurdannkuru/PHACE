"""MSA trimmer module. Provides utilities to trim MSA data by reference sequence 
and/or percentage of gaps in MSA columns.
"""