"""Implements input readers from FASTA formatted files.
"""
